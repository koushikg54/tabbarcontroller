//
//  ViewController.swift
//  testApp1
//
//  Created by koushik ghosh on 02/05/18.
//  Copyright © 2018 koushik ghosh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        for i in stride(from: 0, to: 10, by: 2) {
            print(i)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

