//
//  Item1ViewController.swift
//  testApp1
//
//  Created by koushik ghosh on 04/05/18.
//  Copyright © 2018 koushik ghosh. All rights reserved.
//

import UIKit

class Item1ViewController: UIViewController {

    var badgeDelegate:SetBadgeProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func action(_ sender: Any) {
        
       badgeDelegate?.setBadgeMethod(param: textField.text!)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
