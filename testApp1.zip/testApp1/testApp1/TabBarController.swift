//
//  TabBarController.swift
//  testApp1
//
//  Created by koushik ghosh on 04/05/18.
//  Copyright © 2018 koushik ghosh. All rights reserved.
//

import UIKit

protocol SetBadgeProtocol {
    func setBadgeMethod(param:String)
}

class TabBarController: UITabBarController, SetBadgeProtocol,  UITabBarControllerDelegate {
    
    var tabOneBarItem:UITabBarItem?
     var tabTwoBarItem2:UITabBarItem?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        // Do any additional setup after loading the view.
        
      
    }
    
     func setBadgeMethod(param:String)
     {
        tabOneBarItem?.badgeValue = param
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create Tab one
        let tabOne:Item1ViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Item1ViewController") as! Item1ViewController //Item1ViewController()
        
        
        //tabOne. = self
        
        tabOne.badgeDelegate = self
        
        tabOneBarItem = UITabBarItem(title: "Tab 1", image: UIImage(named: "Home-32.png"), selectedImage: UIImage(named: "Home-32.png"))
        
      // ç
        
        if #available(iOS 10.0, *) {
            tabOneBarItem?.badgeColor = UIColor.blue
            
        } else {
            // Fallback on earlier versions
        }
        
        tabOne.tabBarItem = tabOneBarItem
        
        
        // Create Tab two
        let tabTwo =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController //Item1ViewController()
        
        
         tabTwoBarItem2 = UITabBarItem(title: "Tab 2", image: UIImage(named: "MessageGroup-50.png"), selectedImage: UIImage(named: "MessageGroup-50.png"))
        
        //tabTwoBarItem2?.badgeValue = "2"
        
        if #available(iOS 10.0, *) {
            tabTwoBarItem2?.badgeColor = UIColor.blue
            
        } else {
            // Fallback on earlier versions
        }
        
        tabTwo.tabBarItem = tabTwoBarItem2
        
        
     
        
        self.viewControllers = [tabOne, tabTwo]
    }
    
    // UITabBarControllerDelegate method
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
      
        
        
        
    }
}
