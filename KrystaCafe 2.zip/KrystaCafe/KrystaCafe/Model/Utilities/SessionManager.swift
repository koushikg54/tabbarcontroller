//
//  SessionManager.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 22/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Alamofire

class SessionManager {
    static let sharedInstance = SessionManager()
    
    let apiUrlString = Constants.API.URLString
    private let alamofireManager = Alamofire.SessionManager.default
    
    private init() {
        alamofireManager.startRequestsImmediately = false
    }
    
    func request(_ url: URLConvertible, method: HTTPMethod, parameters: Parameters? = nil, encoding: ParameterEncoding = JSONEncoding.default, headers: HTTPHeaders? = nil) -> DataRequest {
        return alamofireManager.request(url, method: method, parameters: parameters, encoding: encoding, headers: headers)
    }
    
    func cancelAllRequests()
    {
        alamofireManager.session.getTasksWithCompletionHandler
            {
                dataTasks, uploadTasks, downloadTasks in
                for task in dataTasks
                {
                    task.cancel()
                }
        }
    }
    
    func cancelAllRequestsWithUrlPart(_ urlPartString: String)
    {
        alamofireManager.session.getTasksWithCompletionHandler
            {
                dataTasks, uploadTasks, downloadTasks in
                for task in dataTasks
                {
                    if task.originalRequest!.url!.absoluteString.contains(urlPartString) { task.cancel() }
                }
        }
    }
}
