//
//  BaseViewController.swift
//  KrystaCafe
//
//  Created by Janhavi Surve on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: Helper Functions
    func setBadgeCountToCartNavButton(badgeCount: String)
    {
        let notificationButton = CustomBadgeButton()
        notificationButton.frame = CGRect(x: 0, y: 0, width: 44, height: 44)
        notificationButton.setImage(UIImage(named: "Cart")?.withRenderingMode(.alwaysOriginal), for: .normal)
        notificationButton.setImage(UIImage(named: "Cart")?.withRenderingMode(.alwaysOriginal), for: .disabled)
        notificationButton.badgeEdgeInsets = UIEdgeInsets(top: 20, left: 0, bottom: 0, right: 15)
        notificationButton.badge = badgeCount
        notificationButton.addTarget(self, action: #selector(segueCallToToProductCheckoutFromHome), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: notificationButton)
    }
 

    @objc func segueCallToToProductCheckoutFromHome()
    {
         performSegue(withIdentifier: "segueToCheckoutScreen", sender: self)
    }
}
