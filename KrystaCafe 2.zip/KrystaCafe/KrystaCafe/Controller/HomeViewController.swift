//
//  HomeViewController.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 21/05/18.
//  Copyright © 2018 Tushar Shende. All rights reserved.
//

import UIKit
import Alamofire

class HomeViewController: BaseViewController {

    @IBOutlet weak var infoNavButtonOutlet: UIBarButtonItem!
    @IBOutlet weak var cartNavButtonOutlet: UIBarButtonItem!
     var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var promotionButtonOutlet: UIButton!
    @IBOutlet weak var favouriteButtonOutlet: UIButton!
    @IBOutlet weak var loadingView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        makeRoundedCornerButton(button: promotionButtonOutlet)
        makeRoundedCornerButton(button: favouriteButtonOutlet)
        loadingView.isHidden = true
    }

    /*override func viewWillAppear(_ animated: Bool) {
        
        if((UserDefaults.standard.string(forKey: "cartProductCount") ?? "") != "")
        {
        setBadgeCountToCartNavButton(badgeCount: (UserDefaults.standard.string(forKey: "cartProductCount")!))
    }
    }*/
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //get cart item count from stored value
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
    }
    
    func makeRoundedCornerButton(button: UIButton)
    {
        button.backgroundColor = .clear
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.black.cgColor
    }
    
    @IBAction func infoNavButtonAction(_ sender: Any) {
        getLatestOrderDetails()
    }
    @IBAction func cartButtonAction(_ sender: Any) {
         segueCallToToProductCheckoutFromHome()
    }
    
    func getLatestOrderDetails()
    {
         // let todosEndpoint: String = /*Configuration.API.URLString*/ "" + "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        let todosEndpoint: String = "http://alexa-cafe.cloudhub.io/alexa/" + /*"order/cc8deee2da54d5e6"*/  "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        //let url = todosEndpoint.data(using: String.Encoding.utf8)
        
        loadingView.isHidden = false
        
        OrderListRequest(url: todosEndpoint, methodType: .get, encoding: JSONEncoding.default).getOrderList({ (orderDict) in
            
            self.loadingView.isHidden = true
            
            if orderDict.count > 0 {
                
                let orderId = orderDict["orderId"] as! Int
                let orderStatus = orderDict["status"] as! String
                
                self.showAlert(title: "KrystsCafe", message: orderStatus ,orderId:"\(orderId)",orderStatus:"\(orderStatus)")
            } else {
                self.showAlert(title: "KrystsCafe", message: "No active order found.",orderId:"",orderStatus:"")
            }
            
        }) { (error) in
            self.loadingView.isHidden = true
        }
       
    }
    
    
    
    func showAlert(title:String, message:String, orderId:String, orderStatus:String)
{
        if(orderId == "") {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
           
            alert.addAction(UIAlertAction(title: (orderStatus == "complete" ? "OK" : "Done"), style: .default, handler: { action in
             
            alert.dismiss(animated: false, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
        } else {
            
            let alert = UIAlertController(title: title, message: "Order No. is " + orderId, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: (orderStatus == "complete" ? "OK" : "Done"), style: .default, handler: { action in
                
                if(orderStatus == "complete")
                {
                    alert.dismiss(animated: true, completion: {
                        
                    })
                }else{
                    
                    let urlString: String = Constants.API.placeOrderUrl
                    self.loadingView.isHidden = false
                    OrderListRequest(url: urlString, methodType: .put, encoding: JSONEncoding.default, parameters: ["orderId": orderId,"status":orderStatus], headers: [:]).postOrderList({ (orderDict) in
                        
                        self.loadingView.isHidden = true
                        
                        _ = orderDict["orderId"] as! Int
                        let orderStatus = orderDict["status"] as! String
                        
                        self.showAlert(title: "KrystsCafe", message: orderStatus ,orderId:"",orderStatus:"")
                        
                    }, failure: { (error) in
                        print(error!)
                        
                        self.loadingView.isHidden = true
                    })
                    
                }
                
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func favouriteButton_Clicked(_ sender: UIButton) {
        self.performSegue(withIdentifier: "favouriteProductSegue", sender: self)
    }
    
    
    @IBAction func promotionButton_Clicked(_ sender: UIButton) {
        self.performSegue(withIdentifier: "promotionProductSegue", sender: self)
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "favouriteProductSegue" {
            let productListVC = segue.destination as! ProductListViewController
            productListVC.isFavouriteProductList = true
        } else if segue.identifier == "promotionProductSegue" {
            let productListVC = segue.destination as! ProductListViewController
            productListVC.isFavouriteProductList = false
        }
    }

    
}
