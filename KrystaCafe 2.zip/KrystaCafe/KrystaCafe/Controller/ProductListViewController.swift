//
//  ProductListViewController.swift
//  KrystaCafe
//
//  Created by Janhavi Surve on 22/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit
import Alamofire

class ProductListViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource, orderItemCellDelegate {
    
    @IBOutlet weak var productListTableView: UITableView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var productListTitle : String = ""
    var isFavouriteProductList : Bool = false
    //This is the count to be displayed in Cart
    var cartProductCount = 0
    //This is the item count of each product selected, this would be used for price calculation during checkout
    var products = [Product]()
    var promotions = [Promotions]()
    var productForCartItem = [Product]()
    var promotionForCartItem = [Promotions]()
    var cartItems = [CartItem]()
    let appdelegate = UIApplication.shared.delegate as? AppDelegate
    
    // MARK: - Lifecycle Fucntions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.productListTableView.register(UINib(nibName: "OrderItemListCell", bundle: nil), forCellReuseIdentifier: "OrderItemListCell")
        // Do any additional setup after loading the view.
        activityIndicator.isHidden = true
        productListTableView.tableFooterView = UIView(frame: .zero)
        
        //setBadgeCountToCartNavButton(badgeCount: String(cartProductCount))
        productListTableView.tableFooterView = UIView(frame: .zero)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //get cart item count from stored value
        if isFavouriteProductList {
            self.navigationItem.title = "Favourites"
            getFavouritesProductList()
        } else {
            self.navigationItem.title = "Promotions"
            getPromotionProductList()
        }
        /*
         cartProductCount = UserDefaultsUtility.getIntFromDefaults(key: Constants.ConstantKeys.kUserCartItemCount)
         setBadgeCountToCartNavButton(badgeCount: String(cartProductCount))
         */
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
    }
    
    func getPromotionProductList() {
        productListTableView.isHidden = true
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        
        PromotionListRequest().getPromotionsProductList({ (promotionArray: [Promotions]) in
//            if promotionArray.count == 2 {
//                self.productListTableView.rowHeight = 93.0
//            }
            self.promotions = promotionArray
            self.productListTableView.reloadData()
            self.productListTableView.isHidden = false
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        }) { (error) in
            print(error?.localizedDescription ?? "")
            self.activityIndicator.stopAnimating()
            self.activityIndicator.isHidden = true
        }
    }
    
    func getFavouritesProductList() {
        productListTableView.isHidden = true
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        
        ProductListRequest().getFavouritesProductList({ (productArray: [Product]) in
            
//            if productArray.count == 2 {
//                self.productListTableView.rowHeight = 93.0
//            }
            
            self.products = productArray
            self.productListTableView.reloadData()
            self.productListTableView.isHidden = false
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        }) { (error) in
            print(error?.localizedDescription ?? "")
            self.activityIndicator.stopAnimating()
            self.activityIndicator.isHidden = true
        }
        
        //setBadgeCountToCartNavButton(badgeCount: String(cartProductCount))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UITableViewDataSource methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFavouriteProductList {
            return products.count
        } else {
            return promotions.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("CellForRow called")
        let cell = productListTableView.dequeueReusableCell( withIdentifier: "OrderItemListCell") as! OrderItemListCell
       
        
        cell.delegate = self
        cell.indexPath = indexPath
         var isFound:Bool = false
         var prodId:String = ""
         var unitQuintity:Int = 0
        productListTableView.estimatedRowHeight = 130
        productListTableView.rowHeight = UITableViewAutomaticDimension
        
        if isFavouriteProductList {
            let product = products[indexPath.row]
            cell.productNameLabel.text = product.productName
            cell.productDescriptionLabel.text = product.productDesc
            cell.productPriceLabel.text = product.listPrice
            cell.itemCountLabel.text = String(product.quantityNo)
            loadImageForProduct(indexPath, cell: cell, imageUrl: Constants.API.favouritesProductImageUrl)
            prodId = product.productID
        } else  {
            let promotion = promotions[indexPath.row]
            cell.productNameLabel.text = promotion.promoName
            cell.productDescriptionLabel.text = promotion.promoDescr
            cell.productPriceLabel.text = promotion.promoCost
            cell.itemCountLabel.text = String(promotion.promoQty)
            if promotion.promoCategory == "Marketing" {
                //if marketing thrn hide the view to add or remove items
                cell.addItemView.isHidden = true
            } else {
                cell.addItemView.isHidden = false
            }
            loadImageForProduct(indexPath, cell: cell, imageUrl: Constants.API.promotionsProductImageUrl + String(promotion.promoID) + ".jpg")
             prodId = promotion.promoID
        }
       
        for item in CartItemManager.cartItemsDict
        {
            
            if (item.key.productID == prodId)
            {
               // cartItemKey = item.key
                isFound = true
                unitQuintity = item.key.cartQuantityNo
                break;
            }
        
        }
        if(isFound == true)
        {
            cell.itemCountLabel.text = "\(unitQuintity)"
        }
      
        return cell
    }
    
    func loadImageForProduct(_ indexPath: IndexPath, cell: OrderItemListCell, imageUrl: String) {
        
        let getImageRequest: GetImageRequest = GetImageRequest(url: imageUrl)
        
        if URLCache.shared.cachedResponse(for: getImageRequest.request.request!) == nil
        {
            cell.orderItemImageView.image = UIImage(named: "promotion_item1")
            
            cell.setNeedsLayout()
            if self.productListTableView.isDragging || self.productListTableView.isDecelerating { return }
        }
        
        getImageRequest.getImage(
            {
                (image : UIImage) in
                DispatchQueue.main.async
                    {
                        cell.orderItemImageView!.image = image
                        cell.setNeedsLayout()
                }
        },
            failure:
            {
                _ in
                cell.orderItemImageView.image = UIImage(named: "promotion_item1")
        })
    }
    
    // MARK: - OrderItemListCell Delegate Functions
    func addItemTapped(at index: IndexPath) {
        print(index.row)
        let cell = productListTableView.cellForRow(at: index) as! OrderItemListCell
        if isFavouriteProductList {
            let product = products[index.row]
            if product.quantityNo == 0 {
                cartProductCount = cartProductCount + 1
            }
            //product.quantityNo = product.quantityNo + 1
            let imageUrl = Constants.API.favouritesProductImageUrl + String(product.productID) + ".jpg"
            product.quantityNo = Int(cell.itemCountLabel.text!)! + 1
            products[index.row] = product
            addToCartForFavourite(favItem: product, count: product.quantityNo, isAdd: true)
        } else {
            let promotion = promotions[index.row]
            if promotion.promoQty == 0 {
                cartProductCount = cartProductCount + 1
            }
            //promotion.quantityNo = promotion.promoQty + 1
            promotion.promoQty = Int(cell.itemCountLabel.text!)! + 1
            addToCartForPromotions(promo: promotions[index.row], count: promotion.promoQty)
        }
        
        
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
        self.productListTableView.reloadData()
    }
    
    func removeItemTapped(at index: IndexPath) {
       let cell = productListTableView.cellForRow(at: index) as! OrderItemListCell
        
        if isFavouriteProductList {
            let product = products[index.row]
            if Int(cell.itemCountLabel.text!)! == 0 {
                return
            }
            if Int(cell.itemCountLabel.text!)! > 0 {
                //product.quantityNo = product.quantityNo - 1
                 product.quantityNo = Int(cell.itemCountLabel.text!)! - 1
                addToCartForFavourite(favItem: products[index.row], count: product.quantityNo, isAdd: false)
                
            }
            /*
            if cartProductCount > 0 && product.quantityNo == 0 {
                cartProductCount = cartProductCount - 1
                
                
                addToCartForFavourite(favItem: products[index.row], count: product.quantityNo, isAdd: false)
                
            }*/
            
        } else {
            let promotion = promotions[index.row]
            if promotion.promoQty == 0 {
                return
            }
            if promotion.promoQty > 0 {
                 promotion.promoQty = Int(cell.itemCountLabel.text!)! - 1
               // promotion.promoQty = promotion.promoQty - 1
                addToCartForPromotions(promo: promotions[index.row], count: promotion.promoQty)
                
            }
            if cartProductCount > 0 && promotion.promoQty == 0 {
                //cartProductCount = cartProductCount - 1
                 promotion.promoQty = Int(cell.itemCountLabel.text!)! - 1
                addToCartForPromotions(promo: promotions[index.row], count: promotion.promoQty)
                
            }
            //promotionForCartItem.remove(at: index.row)
        }
        
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
        self.productListTableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToCheckoutScreen" {
            let productCheckOutVC = segue.destination as! ProdcutCheckoutViewController
            let cartItem = CartItem()
            cartItem.products = productForCartItem
            cartItem.promotion = promotionForCartItem
            productCheckOutVC.cartItem = cartItem
        }
    }
    func addToCartForFavourite(favItem:Product, count:Int, isAdd:Bool ) {
        
        let cartItem:CartItem1 = CartItem1(quantityNo: favItem.quantityNo, productType: favItem.productType, productID: favItem.productID, productDesc: favItem.productDesc, productPrice: favItem.listPrice, productName: favItem.productName, price: favItem.listPrice, imageUrl: "\(favItem.productID)",cartQuantityNo: count)
        
        print(CartItemManager.cartItemsDict)
        
      
        CartItemManager.updateCart(cartItem: cartItem, count: count, isAdd: isAdd)
        
    }
    
    
    
    func addToCartForPromotions(promo:Promotions,count:Int){
        
        let cartItem:CartItem1 = CartItem1(quantityNo: promo.promoQty, productType: promo.promoType, productID: promo.promoID, productDesc: promo.promoDescr, productPrice: promo.promoCost, productName: promo.promoName, price: promo.promoCost, imageUrl: "\(promo.promoID)",cartQuantityNo:count)
        CartItemManager.updateCart(cartItem: cartItem, count: count, isAdd: false)
        
  
        
    }
    
}
