//
//  ProdcutCheckoutViewController.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 24/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit

class ProdcutCheckoutViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource, orderItemCellDelegate {

    @IBOutlet weak var productListTableView: UITableView!
    @IBOutlet weak var cartTotalLabel: UILabel!
    @IBOutlet weak var totalPriceLabel: UILabel!
    @IBOutlet weak var emptyCartImageView: UIView!
    
    var cartItem = CartItem()
    var products = [Product]()
    var promotions = [Promotions]()
    var cartProductCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        productListTableView.register(UINib(nibName: "OrderItemListCell", bundle: nil), forCellReuseIdentifier: "OrderItemListCell")
        // Do any additional setup after loading the view.

//        productListTableView.estimatedRowHeight = 90
//        productListTableView.rowHeight = UITableViewAutomaticDimension
        // manageCartItem()
        // self.productListTableView.performSelector(onMainThread: (#selector(UICollectionView.reloadData)), with: nil, waitUntilDone: true)
        emptyCartImageView.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.cartTotalLabel.text = "Cart Total :" + "\(CartItemManager.getCartItemsCount())"
        self.totalPriceLabel.text = "Total price :" + "\(CartItemManager.getTotalCartItemsPrice())"
        
        productListTableView.tableFooterView = UIView(frame: .zero)
        productListTableView.reloadData()
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
        showEmptyCartImageView()
        self.navigationItem.rightBarButtonItem?.isEnabled = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    func showEmptyCartImageView() {
        if CartItemManager.getCartItemsCount() == 0     {
            emptyCartImageView.isHidden = false
        } else {
            emptyCartImageView.isHidden = true
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CartItemManager.getCartItemsCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell( withIdentifier: "OrderItemListCell") as! OrderItemListCell
        cell.delegate = self
        cell.indexPath = indexPath
        // let product = products[indexPath.row]
        cell.productNameLabel.text = CartItemManager.getCartItemsAsList()[indexPath.row].productName
        cell.productPriceLabel.text = CartItemManager.convertToTotalPriceWithDollor(price: CartItemManager.getCartItemsAsList()[indexPath.row].price, count: CartItemManager.getCartItemsAsList()[indexPath.row].cartQuantityNo)
        cell.productDescriptionLabel.text = CartItemManager.getCartItemsAsList()[indexPath.row].productDesc
        cell.itemCountLabel.text = String(CartItemManager.getCartItemsAsList()[indexPath.row].cartQuantityNo)
        loadImageForProduct(indexPath, cell: cell, imageUrl: CartItemManager.getCartItemsAsList()[indexPath.row].imageUrl)
        
        return cell
    }
    
    func addItemTapped(at index: IndexPath) {
        
        let cart = CartItemManager.getCartItemsAsList()[index.row]
       
        cart.cartQuantityNo = cart.cartQuantityNo + 1
        
        //let imageUrl = Constants.API.favouritesProductImageUrl + String(cart.productID) + ".jpg"
       
       // cartProductCount = cart.cartQuantityNo
         let cartItem:CartItem1 = CartItem1(quantityNo: cart.cartQuantityNo, productType: cart.productType, productID: cart.productID, productDesc: cart.productDesc, productPrice: cart.productPrice, productName: cart.productName, price: cart.productPrice, imageUrl: "\(cart.productID)",cartQuantityNo:cart.cartQuantityNo)
        
       updateToCart(cart: cartItem, count: cart.cartQuantityNo)
        
       // setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
        self.productListTableView.reloadData()
        self.cartTotalLabel.text = "Cart Total :" + "\(CartItemManager.getCartItemsCount())"
          self.totalPriceLabel.text = "Total price :" + "\(CartItemManager.getTotalCartItemsPrice())"
        
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
        self.navigationItem.rightBarButtonItem?.isEnabled = false
    }
    
    func removeItemTapped(at index: IndexPath) {
         let cart = CartItemManager.getCartItemsAsList()[index.row]
        if cart.cartQuantityNo == 0 {
            return
        }
        if cart.cartQuantityNo > 0 {
            cart.cartQuantityNo = cart.cartQuantityNo - 1
            let cartItem:CartItem1 = CartItem1(quantityNo: cart.cartQuantityNo, productType: cart.productType, productID: cart.productID, productDesc: cart.productDesc, productPrice: cart.productPrice, productName: cart.productName, price: cart.productPrice, imageUrl: "\(cart.productID)",cartQuantityNo:cart.cartQuantityNo)
            
            updateToCart(cart: cartItem, count: cart.cartQuantityNo)
            
        }
        if ((cart.cartQuantityNo) > 0 && (cart.cartQuantityNo) == 0) {
            cart.cartQuantityNo = cart.cartQuantityNo - 1
            
            let cartItem:CartItem1 = CartItem1(quantityNo: cart.cartQuantityNo, productType: cart.productType, productID: cart.productID, productDesc: cart.productDesc, productPrice: cart.productPrice, productName: cart.productName, price: cart.productPrice, imageUrl: "\(cart.productID)",cartQuantityNo:cart.cartQuantityNo)
            
            updateToCart(cart: cartItem, count: cart.cartQuantityNo)
            self.navigationItem.rightBarButtonItem?.isEnabled = false
            
        }
       // setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
        self.productListTableView.reloadData()
         self.cartTotalLabel.text = "Cart Total :" + "\(CartItemManager.getCartItemsCount())"
          self.totalPriceLabel.text = "Total price :" + "\(CartItemManager.getTotalCartItemsPrice())"
        
        showEmptyCartImageView()
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
    }
    
    func loadImageForProduct(_ indexPath: IndexPath, cell: OrderItemListCell, imageUrl: String) {
        
        let getImageRequest: GetImageRequest = GetImageRequest(url: imageUrl)
        
        if URLCache.shared.cachedResponse(for: getImageRequest.request.request!) == nil
        {
            cell.orderItemImageView.image = UIImage(named: "promotion_item1")
            
            cell.setNeedsLayout()
            if self.productListTableView.isDragging || self.productListTableView.isDecelerating { return }
        }
        
        getImageRequest.getImage(
            {
                (image : UIImage) in
                DispatchQueue.main.async
                    {
                        cell.orderItemImageView!.image = image
                        cell.setNeedsLayout()
                }
        },
            failure:
            {
                _ in
                cell.orderItemImageView.image = UIImage(named: "promotion_item1")
        })
    }
    
  
    func updateToCart(cart:CartItem1,count:Int){
        
        let cartItem:CartItem1 = CartItem1(quantityNo: cart.cartQuantityNo, productType: cart.productType, productID: cart.productID, productDesc: cart.productDesc, productPrice: cart.productPrice, productName: cart.productName, price: cart.productPrice, imageUrl: "\(cart.productID)",cartQuantityNo:count)
        CartItemManager.updateCart(cartItem: cartItem, count: count, isAdd: false)
        
        
        
    }

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
