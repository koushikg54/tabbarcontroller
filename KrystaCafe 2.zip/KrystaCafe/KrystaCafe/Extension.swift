//
//  Extension.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Foundation
