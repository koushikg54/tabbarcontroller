//
//  CartItemData.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 24/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//
import UIKit
import Foundation
class CartItemData : NSObject{
    var count: Int = 0
    var price: String = ""
    override init() {
        
    }
    init(count: Int, price: String) {
        
        self.count = count
        self.price = price
       
    }
}

