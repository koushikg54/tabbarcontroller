//
//  Product.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 22/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Foundation

import Foundation

class Product {
    //private String quantityName;
    
    var quantityNo: Int = 0
    var productType: String = ""
    var tenantID: Int = 0
    var productID: String = ""
    var productDesc: String = ""
    var prepTime: Any?
    var calories: String = ""
    var listPrice: String = ""
    var sKU: String = ""
    var productName: String = ""
    var productIsAdded: Bool = false
    
    init(productDict: [String : Any]) {
        //self.quantityNo = productDict[""]
        //self.productType =
        //self.tenantID =
        self.productID =  productDict["productID"] as! String
        self.productDesc = productDict["productDesc"] as! String
        //self.prepTime =
        //self.calories =
        self.listPrice = productDict["listPrice"] as! String
        //self.sKU =
        self.productName = productDict["productName"] as! String
        self.quantityNo = productDict["quantityNo"] as! Int
    }
}
