//
//  ActivityIndicator.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Foundation
import UIKit

class ActivityIndicator: NSObject {
    
    
    static func StartActivityIndicator(obj:UIViewController) -> UIActivityIndicatorView
    {
        var myActivityIndicator:UIActivityIndicatorView!
        myActivityIndicator = UIActivityIndicatorView(frame:CGRect(x:100,y: 100,width: 100,height: 100)) as UIActivityIndicatorView;
        
        myActivityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        myActivityIndicator.center = obj.view.center;
        
        obj.view.addSubview(myActivityIndicator);
        // obj.view.userInteractionEnabled = false
        myActivityIndicator.startAnimating();
        return myActivityIndicator;
    }
    
    static func StartActivityIndicatorNew(obj:UIViewController) -> UIActivityIndicatorView
    {
        var myActivityIndicator:UIActivityIndicatorView!
        myActivityIndicator = UIActivityIndicatorView(frame:CGRect(x:100,y: 100,width: 100,height: 100)) as UIActivityIndicatorView;
        
        myActivityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        //myActivityIndicator.center = obj.view.center;
        
        obj.view.addSubview(myActivityIndicator);
        // obj.view.userInteractionEnabled = false
        myActivityIndicator.startAnimating();
        return myActivityIndicator;
    }
    
    static func StopActivityIndicator(obj:UIViewController,indicator:UIActivityIndicatorView)-> Void
    {
        indicator.removeFromSuperview();
        // obj.view.userInteractionEnabled = true
    }
    
    static func DialogStartActivityIndicator(obj:UIViewController) -> UIActivityIndicatorView
    {
        var myActivityIndicator:UIActivityIndicatorView!
        myActivityIndicator = UIActivityIndicatorView(frame:CGRect(x:100,y: 100,width: 100,height: 100)) as UIActivityIndicatorView;
        
        myActivityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        myActivityIndicator.center = obj.view.center;
        obj.view.addSubview(myActivityIndicator);
        obj.view.isUserInteractionEnabled = false
        myActivityIndicator.startAnimating();
        return myActivityIndicator;
    }
    static func DialogStopActivityIndicator(obj:UIViewController,indicator:UIActivityIndicatorView)-> Void
    {
        indicator.removeFromSuperview();
        obj.view.isUserInteractionEnabled = true
    }
    
    
}
