//
//  CartItem1.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 25/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit
class CartItem1 : NSObject {
    var quantityNo: Int = 0
    var productType: String = ""
    var productID: String = ""
    var productDesc: String = ""
    var productPrice: String = ""
    var productName: String = ""
    var price: String = ""
    var imageUrl: String = ""
    var cartQuantityNo: Int = 0
    override init() {
        
    }
    init(quantityNo: Int, productType: String,productID: String, productDesc:String, productPrice:String,productName:String, price:String,imageUrl:String,cartQuantityNo: Int) {
        
        self.quantityNo = quantityNo
        self.productType = productType
        self.productID = productID
        self.productDesc = productDesc
        self.productPrice = productPrice
        self.productName = productName
        self.price = price
        self.imageUrl = imageUrl
        self.cartQuantityNo = cartQuantityNo
        
    }
}
