//
//  PromotionListRequest.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Alamofire

class PromotionListRequest {
    
    var request: DataRequest
    
    init() {
        request = SessionManager.sharedInstance.request( Constants.API.productPromotionUrl, method: .get, parameters: nil, headers: nil)
    }
    
    func getPromotionsProductList(_ success: @escaping ([Promotions]) -> Void, failure: @escaping (Error?) -> Void) {
        let promotionDict = [["promoName": "Promotion name1", "promoDescr": "Product description", "promoCost": "34$", "promoQty": 0, "promoID": "3"], ["promoName": "Promotion name2", "promoDescr": "Product description", "promoCost": "12$", "promoQty": 0 , "promoID": "4"]]
        var promotions = [Promotions]()
        
        print("GetAppsRequest: \(request.request!.url!.absoluteString)")
        request.response
            {
                response in
                
                if response.response != nil {
                    let responseString = String(data: response.data!, encoding: String.Encoding.utf8)
                    print("GetAppsResponse: \(responseString!)")
                    let JSON = try? JSONSerialization.jsonObject(with: response.data!, options: JSONSerialization.ReadingOptions.allowFragments)
                    if JSON != nil {
                        let promotionArray = JSON as! [[String : Any]]
                        //let promotionArray = root["apps"] as! [[String : AnyObject]]
                        
                        for item in promotionArray {
                            
                            promotions.append(Promotions(dict: item))
                        }
                        success(promotions)
                    } else {
                        for item in promotionDict {
                            promotions.append(Promotions(dict: item))
                        }
                        success(promotions)
                    }
                }
                else {
                    for item in promotionDict {
                        promotions.append(Promotions(dict: item))
                    }
                    success(promotions)
                }
        }
        
        request.resume()
    }
}
