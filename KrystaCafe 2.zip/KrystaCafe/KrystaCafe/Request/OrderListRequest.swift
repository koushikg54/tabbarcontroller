//
//  OrderListRequest.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 25/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Alamofire

class OrderListRequest {
    
    var request: DataRequest
    
    init(url: String, methodType: HTTPMethod,encoding : ParameterEncoding, parameters: Parameters? = nil, headers: HTTPHeaders? = nil) {
        request = SessionManager.sharedInstance.request( url, method: methodType, parameters: parameters, encoding: encoding, headers: headers)
    }
    
    func getOrderList(_ success: @escaping ([String: Any]) -> Void, failure: @escaping (Error?) -> Void) {
        print("GetAppsRequest: \(request.request!.url!.absoluteString)")
        
        request.responseJSON {
            response in
            switch response.result {
            case .success:
                    
                    print(response)
                    do {
                        let readableJSON = try JSONSerialization.jsonObject(with: response.data!, options:.allowFragments) as! NSArray
                        
                        
                        if(readableJSON.count > 0)
                        {
                            let orderDict = readableJSON[0] as! [String :Any]
                            success(orderDict)
                        }else{
                            failure(response.error)
                        }
                        
                    }
                    catch {
                        print(error)
                    }
                break
            case .failure(let error):
                
                print(error)
                // self.getLatestOrderDetails()
            }
        }
        request.resume()
    }
    
    func postOrderList(_ success: @escaping ([String: Any]) -> Void, failure: @escaping (Error?) -> Void) {
        print("GetAppsRequest: \(request.request!.url!.absoluteString)")
        
        request.responseJSON {
            response in
            switch response.result {
            case .success:
                
                print(response)
                do {
                    let readableJSON = try JSONSerialization.jsonObject(with: response.data!, options:.allowFragments) as! [String : Any]
                    
                    
                    if(readableJSON.count > 0)
                    {
                        let orderDict = readableJSON
                        success(orderDict)
                    }else{
                        failure(response.error)
                    }
                    
                }
                catch {
                    print(error)
                }
                break
            case .failure(let error):
                
                print(error)
                // self.getLatestOrderDetails()
            }
        }
        request.resume()
    }
}
