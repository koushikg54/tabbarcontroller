//
//  Constants.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 22/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

struct Constants
{
    struct API
    {
        //static let URLString = "https://sogetiapi.com/appitecture"
        static let baseUrl = "http://alexa-cafe.cloudhub.io:80/alexa/"
        static let favouritesProductImageUrl = "http://s3.amazonaws.com/kristacafe01/products/"
        static let promotionsProductImageUrl = "http://s3.amazonaws.com/kristacafe01/promotions/"
        static let productFavoriteUrl = "http://alexa-cafe.cloudhub.io:80/alexa/"
        static let productPromotionUrl = "http://alexa-cafe.cloudhub.io/alexa/promotions"
        static let placeOrderUrl = "http://alexa-cafe.cloudhub.io/alexa/order"
        static let setPickUpLocation = "http://alexa-cafe.cloudhub.io/alexa/find?location=55136"
    }
    
    struct KafeAddress
    {
        static let defaultPickUpAddress =  """
Krista's Kafe 46th Main Street,Belchertown \nMA 010007
"""
        static let defaultDeliverAddress =  """
       Vasario 16-osios g. 70 \nJonava 55165 \nLithuania"
"""
        static let noDeliverAddressFound =  "Sorry! could not locate any"
    }
    
    /**
     It provide constant keys that are used throughout the application.
     */
    struct ConstantKeys {
        static let kUserCartItemCount = "CartItemCount"
    }
}
