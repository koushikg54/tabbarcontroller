//
//  UserDefaultsUtility.swift
//  KrystaCafe
//
//  Created by Janhavi Surve on 24/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit

class UserDefaultsUtility: NSObject {
    /**
     This method will set Int value to UserDefaults.
     - Parameter keyString
     keyString of type string
     - Parameter value
     value of type Int
     */
    static func storeIntToDefaults(key keyString: String, value: Int) {
        if keyString.count > 0 {
            let defaults = UserDefaults.standard
            defaults.set(value, forKey: keyString)
            defaults.synchronize()
        } else {
            print("Empty key sent to set data to user defaults")
        }
    }
    
    /**
     This method will get Int value from UserDefaults.
     - Parameter keyString
     keyString of type string
     - returns: Int
     */
    static func getIntFromDefaults(key keyString: String) -> Int {
        if keyString.count > 0 {
            let defaults = UserDefaults.standard
            return defaults.integer(forKey: keyString)
        } else {
            print("Empty key sent to retrieve data from user defaults")
            return 0
        }
    }
}
