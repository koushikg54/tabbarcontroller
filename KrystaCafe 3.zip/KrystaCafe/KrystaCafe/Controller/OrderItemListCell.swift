//
//  OrderItemListCell.swift
//  KrystaCafe
//
//  Created by Janhavi Surve on 22/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit

protocol orderItemCellDelegate{
    func addItemTapped(at index:IndexPath)
    func removeItemTapped(at index:IndexPath)
}

class OrderItemListCell: UITableViewCell {
    
    var delegate:orderItemCellDelegate!
    @IBOutlet weak var orderItemImageView: UIImageView!
    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var productDescriptionLabel: UILabel!
    @IBOutlet weak var productPriceLabel: UILabel!
    @IBOutlet weak var addItemView: UIView!
    @IBOutlet weak var itemCountLabel: UILabel!
    var indexPath:IndexPath!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    //User action to remove items from cart
    @IBAction func removeItemButtonTapped(_ sender: Any) {
        self.delegate?.removeItemTapped(at: indexPath)
    }
    
    //User action to add items in cart
    @IBAction func addItemButtonTapped(_ sender: Any) {
        self.delegate?.addItemTapped(at: indexPath)
    }
    
}
