//
//  OrderViewController.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit
import Foundation
import CoreLocation
import  Alamofire
import BRYXBanner
import Darwin

class OrderViewController: BaseViewController,UITextViewDelegate {

    @IBOutlet weak var orderAddressView: UIView!
    @IBOutlet weak var orderImageButton: UIButton!
    @IBOutlet weak var orderButtonOutlet: UIButton!
    @IBOutlet weak var deliverToAddressEditText: UITextView!
    @IBOutlet weak var orderStatusLabel: UILabel!
    @IBOutlet weak var deliverToTextView: UITextView!
    @IBOutlet weak var pickUpFromLabel: UILabel!
    @IBOutlet weak var pickUpRadioButtonOutlet: UIButton!
    @IBOutlet weak var deliverRadioButtonOutlet: UIButton!
    @IBOutlet weak var activityIndicatorView: UIView!
    
     var activityIndicator: UIActivityIndicatorView!
    var radioButtonCheckFlag:Bool!
    var orderButtonClickedFlag:Bool!
     var orderId:String!
    let radioBtncheckedImage = UIImage(named: "radioChecked")! as UIImage
    let radioBtnuncheckedImage = UIImage(named: "radioUnchecked")! as UIImage
    let locationManager = CLLocationManager()
    var currentAddress:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //makeRoundedCornerButton(button: orderButtonOutlet)
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        deliverToTextView.delegate = self
        pickUpFromLabel.text = Constants.KafeAddress.defaultPickUpAddress
        deliverToTextView.text =  Constants.KafeAddress.defaultDeliverAddress
        setAddressForOrder()
        if(orderButtonClickedFlag == nil)
        {
            orderButtonClickedFlag = false
        }
        self.navigationController?.navigationBar.backItem?.title = " "
        activityIndicatorView.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func makeRoundedCornerButton(button: UIButton)
    {
        button.backgroundColor = .clear
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.black.cgColor
    }
    
    func displayLocationInfo(placemark: CLPlacemark) {
        
        locationManager.stopUpdatingLocation()
        
        
        currentAddress = (placemark.addressDictionary!["Street"] as! String) + ", " + placemark.locality! + ", " + placemark.administrativeArea! + ", " + (placemark.addressDictionary!["Country"] as! String) + ", " + (placemark.addressDictionary!["ZIP"] as! String)
        
         deliverToTextView.text = currentAddress
    }
    
    @IBAction func pickupButtonAction(_ sender: Any) {
        pickUpRadioButtonOutlet.setImage(radioBtncheckedImage, for: .normal)
        deliverRadioButtonOutlet.setImage(radioBtnuncheckedImage, for: .normal)
    }
    
    @IBAction func deliverToButtonAction(_ sender: Any) {
        deliverRadioButtonOutlet.setImage(radioBtncheckedImage, for: .normal)
        pickUpRadioButtonOutlet.setImage(radioBtnuncheckedImage, for: .normal)
    }
    @IBAction func pickUpRadioButtonAction(_ sender: Any) {
        pickUpRadioButtonOutlet.setImage(radioBtncheckedImage, for: .normal)
        deliverRadioButtonOutlet.setImage(radioBtnuncheckedImage, for: .normal)
    }
    @IBAction func deliverRadioButtonAction(_ sender: Any) {
        deliverRadioButtonOutlet.setImage(radioBtncheckedImage, for: .normal)
        pickUpRadioButtonOutlet.setImage(radioBtnuncheckedImage, for: .normal)
    }
    @IBAction func orderActionButton(_ sender: Any) {
     if(orderButtonClickedFlag == false)
     {
           placeOrder()
        }
     else{
         self.navigationController?.popToRootViewController(animated: true)
         CartItemManager.cartItemsDict  = [:]
        }
    }
   
    func setAddressForOrder()
    {
      
       // activityIndicator = ActivityIndicator.StartActivityIndicator(obj: self)
        // let todosEndpoint: String = /*Configuration.API.URLString*/ "" + "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        let todosEndpoint: String = Constants.API.setPickUpLocation
        /*"order/\(UserDefaults.standard.string(forKey: "uuidString")!)"*/
         /*
        //let todoEndpoint: String = "https://jsonplaceholder.typicode.com/todos/1"
        Alamofire.request(todosEndpoint)
            .responseJSON { response in
                // check for errors
                guard response.result.error == nil else {
                    // got an error in getting the data, need to handle it
                    print("error calling GET on /todos/1")
                    print(response.result.error!)
                     self.pickUpFromLabel.text = Constants.KafeAddress.noDeliverAddressFound
                    return
                }
                
                // make sure we got some JSON since that's what we expect
                guard let json = response.result.value as? [String: Any] else {
                    print("didn't get todo object as JSON from API")
                    if let error = response.result.error {
                        print("Error: \(error)")
                    }
                    return
                }
                
                // get and print the title
                guard let todoTitle = json["geometry"] as? String else {
                    print("Could not get todo title from JSON")
                    return
                }
                self.pickUpFromLabel.text =  "\(todoTitle)"
        }*/
        
       
        Alamofire.request(todosEndpoint, method: .get, encoding: JSONEncoding.default)
            .responseJSON {
                response in
                switch response.result {
                case .success:
                    
                    DispatchQueue.main.async( execute: {
                      //  ActivityIndicator.StopActivityIndicator(obj: self,indicator: self.activityIndicator)
                    
                    
                    print(response)
                    do {
                        let readableJSON = try JSONSerialization.jsonObject(with: response.data!, options:.allowFragments) as! NSArray
                        
                        if(readableJSON.count > 0)
                        {
                            let addressDict = readableJSON[0] as! NSDictionary
                            let addressName = addressDict.value(forKey: "geometry")
                            self.pickUpFromLabel.text =  "\(addressName!)"
                          
                        }
                     
                    }
                    catch {
                        print(error)
                    }
                    })
                    break
                case .failure(let error):
                    DispatchQueue.main.async( execute: {
                      //  ActivityIndicator.StopActivityIndicator(obj: self,indicator: self.activityIndicator)
                 
                    self.pickUpFromLabel.text = Constants.KafeAddress.noDeliverAddressFound
                    print(error)
                           })
                    break
                }
        }
    }
    
    func placeOrder()
    {
    //activityIndicator = ActivityIndicator.StartActivityIndicator(obj: self)
        activityIndicatorView.isHidden = false
       let parameters: Parameters = ["customerId": /*"cc8deee2da54d5e6"*/UserDefaults.standard.string(forKey: "uuidString")!,"fulfillment":"delivery","total":CartItemManager.getTotalCartItemsPriceWithoutDollor()]
        
        let urlString: String = Constants.API.placeOrderUrl
        let url = URL(string: urlString)
        self.orderStatusLabel.text = "Order is placing...."
        
        OrderListRequest(url: urlString, methodType: .post, encoding: JSONEncoding.default, parameters: parameters, headers: [:]).postOrderList({ (orderDict) in
            
           // self.loadingView.isHidden = true
            self.activityIndicatorView.isHidden = true
            let orderId = orderDict["orderId"] as! Int //value(forKey: "orderId")
            self.orderId = "\(orderId)"
            self.orderButtonClickedFlag = true
            self.orderButtonOutlet.setTitle("Done", for: .normal)
            self.orderAddressView.isHidden = true
            self.orderImageButton.isHidden = false
            self.orderStatusLabel.text = """
            Order placed successfully\nOrder Number :"\(self.orderId!)"\nOrder Cost :"\(CartItemManager.getTotalCartItemsPrice())"
            """
             CartItemManager.cartItemsDict  = [:]
            self.getLatestOrderDetails()
            //self.showAlert(title: "KrystsCafe", message: orderStatus ,orderId:"",orderStatus:"")
//            ActivityIndicator.StopActivityIndicator(obj: self,indicator: self.activityIndicator)
        }, failure: { (error) in
            print(error!)
//            ActivityIndicator.StopActivityIndicator(obj: self,indicator: self.activityIndicator)
            self.activityIndicatorView.isHidden = true
           // self.loadingView.isHidden = true
        })
       
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            deliverToTextView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func getLatestOrderDetails()
    {
        // let todosEndpoint: String = /*Configuration.API.URLString*/ "" + "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        let todosEndpoint: String = "http://alexa-cafe.cloudhub.io/alexa/" + /*"order/cc8deee2da54d5e6"*/  "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        //let url = todosEndpoint.data(using: String.Encoding.utf8)
        
        activityIndicatorView.isHidden = false
        
        OrderListRequest(url: todosEndpoint, methodType: .get, encoding: JSONEncoding.default).getOrderList({ (orderDict) in
            
            self.activityIndicatorView.isHidden = true
            
            if orderDict.count > 0 {
                
                let OpenOrderId = orderDict["orderId"] as! Int
                let OpenOrderStatus = orderDict["status"] as! String
                
                UserDefaults.standard.set(OpenOrderId, forKey: "OpenOrderId")
                UserDefaults.standard.set(OpenOrderStatus, forKey: "OpenOrderStatus")
                
                
                NotificationCenter.default.post(name: Notification.Name("NotificationIdentifierForOpenOrder"), object: nil)
              //  self.showAlert(title: "", message: orderStatus ,orderId:"\(orderId)",orderStatus:"\(orderStatus)")
               // self.updateOrderStatus(orderStatus: orderStatus)
            } else {
                //self.showAlert(title: "", message: "No active order found.",orderId:"",orderStatus:"")
            }
            
        }) { (error) in
            self.activityIndicatorView.isHidden = true
        }
        
    }

 
}

extension OrderViewController: CLLocationManagerDelegate {
    // 2
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        // 3
        if status == .authorizedWhenInUse {
            
            // 4
            locationManager.startUpdatingLocation()
            
            //5
            
        }
    }
    
    // 6
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if let location = locations.first {
            
            
            
            CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error) -> Void in
                if (error != nil) {
                    print(
                        
                        "Reverse geocoder failed with error" + error!.localizedDescription)
                    return
                }
                
                if placemarks!.count > 0 {
                    let pm = placemarks![0] as CLPlacemark
                    self.displayLocationInfo(placemark: pm)
                    print(pm.country)
                } else {
                    print(
                        
                        "Problem with the data received from geocoder")
                }
            })
            
            print(
                
                "locations = \(location.coordinate.latitude) \(location.coordinate.longitude)")
            
            //            // 7
            
            //
            // 8
            locationManager.stopUpdatingLocation()
        }
        
    }
}

