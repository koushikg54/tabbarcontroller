//
//  HomeViewController.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 21/05/18.
//  Copyright © 2018 Tushar Shende. All rights reserved.
//

import UIKit
import Alamofire
import BRYXBanner
import Darwin
import AMPopTip

class HomeViewController: BaseViewController {

    @IBOutlet weak var infoNavButtonOutlet: UIBarButtonItem!
    @IBOutlet weak var cartNavButtonOutlet: UIBarButtonItem!
     var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var promotionButtonOutlet: UIButton!
    @IBOutlet weak var favouriteButtonOutlet: UIButton!
    @IBOutlet weak var loadingView: UIView!
    
    @IBOutlet weak var slideButton: UIButton!
    @IBOutlet weak var labelView: UIView!
    @IBOutlet weak var orderStatusLabel: UILabel!
    
    @IBOutlet weak var labelViewLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var labelViewTrailingConstraint: NSLayoutConstraint!
    var isSlideIn = false
    
    /**
     An instance of the *Banner* which will be used for showing how many Steps are completed
     */
    var bannerView: Banner?
    var collapseViewFlag:Bool = false
   // @IBOutlet weak var stickyViewWidth: NSLayoutConstraint!
   // @IBOutlet weak var marginStickyWidth: NSLayoutConstraint!
    
    @IBOutlet weak var dummyTipView: UIView!
    @IBOutlet weak var dummyButtonOutlet: UIButton!
    let popTip = PopTip()
    var direction = PopTipDirection.up
    var topRightDirection = PopTipDirection.down
    var timer: Timer? = nil
    
    @IBOutlet weak var collapseView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        makeRoundedCornerButton(button: promotionButtonOutlet)
        makeRoundedCornerButton(button: favouriteButtonOutlet)
        makeRoundedCornerView(view: loadingView)
        loadingView.isHidden = true
        labelViewLeadingConstraint.constant = -(self.view.frame.width - slideButton.frame.width)
        labelViewTrailingConstraint.constant = self.view.frame.width - slideButton.frame.width
        
        labelView.isOpaque = true
        
        //tipView
        popTip.font = UIFont(name: "Avenir-Medium", size: 12)!
        popTip.shouldDismissOnTap = true
        popTip.shouldDismissOnTapOutside = true
        popTip.shouldDismissOnSwipeOutside = true
        popTip.edgeMargin = 5
        popTip.offset = 2
        popTip.bubbleOffset = 0
        popTip.edgeInsets = UIEdgeInsetsMake(0, 10, 0, 10)
        
        popTip.actionAnimation = .bounce(8)
        
        popTip.tapHandler = { _ in
            print("tap")
        }
        
        popTip.tapOutsideHandler = { _ in
            print("tap outside")
        }
        
        popTip.swipeOutsideHandler = { _ in
            print("swipe outside")
        }
        
        popTip.dismissHandler = { _ in
            print("dismiss")
        }

        
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifierForOpenOrder"), object: nil)
    }
    
    @objc func methodOfReceivedNotification(notification: Notification){
        dummyButtonOutlet.sendActions(for: .touchUpInside)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        dropShadow()
       
    }
    /*override func viewWillAppear(_ animated: Bool) {
        
        if((UserDefaults.standard.string(forKey: "cartProductCount") ?? "") != "")
        {
        setBadgeCountToCartNavButton(badgeCount: (UserDefaults.standard.string(forKey: "cartProductCount")!))
    }
    }*/
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //get cart item count from stored value
        setBadgeCountToCartNavButton(badgeCount: String(CartItemManager.getCartItemsCount()))
         // promotionButtonOutlet.sendActions(for: .touchUpInside)
        //
        
    }
    @IBAction func dummyButtonAction(_ sender: UIButton) {
        
        popTip.bubbleColor = UIColor(red: 0.31, green: 0.57, blue: 0.87, alpha: 1)
        let attributes: [NSAttributedStringKey: Any] = [NSAttributedStringKey.font: UIFont.systemFont(ofSize: 12), NSAttributedStringKey.foregroundColor: UIColor.white]
        let underline: [NSAttributedStringKey: Any] = [NSAttributedStringKey.font: UIFont.systemFont(ofSize: 13), NSAttributedStringKey.foregroundColor: UIColor.white, NSAttributedStringKey.underlineStyle: NSUnderlineStyle.styleSingle.rawValue]
        let attributedText = NSMutableAttributedString(string: "I'm presenting a string ", attributes: attributes)
        attributedText.append(NSAttributedString(string: "with attributes!", attributes: underline))
        // popTip.show(attributedText: attributedText, direction: .up, maxWidth: 200, in: tempView, from: sender.frame)
        orderStatusLabel.text = "Order No :" + "\(UserDefaults.standard.string(forKey: "OpenOrderId")! ?? "\(0)" )" + "& Order Status: " + "\(UserDefaults.standard.string(forKey: "OpenOrderStatus")! ?? "Open" )"
        popTip.show(text: "Swipe to see  \n latest order details", direction: .up, maxWidth: 200, in: dummyTipView, from: sender.frame)
        popTip.shouldDismissOnTapOutside = true
    }
    
    func dropShadow() {
        
        self.labelView.layer.masksToBounds = false
        self.labelView.layer.shadowColor = UIColor.black.cgColor
        self.labelView.layer.shadowOpacity = 0.5
        self.labelView.layer.shadowOffset = CGSize(width: -1, height: 1)
        self.labelView.layer.shadowRadius = 5
        
        self.labelView.layer.shadowPath = UIBezierPath(rect: self.labelView.bounds).cgPath
        self.labelView.layer.shouldRasterize = true
        
        self.labelView.layer.rasterizationScale = UIScreen.main.scale
        
    }
    
    func makeRoundedCornerButton(button: UIButton)
    {
        button.backgroundColor = .clear
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.black.cgColor
    }
    func makeRoundedCornerView(view: UIView)
    {
        view.backgroundColor = .clear
        view.layer.cornerRadius = 5
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.black.cgColor
    }
    @IBAction func promotionButtonAction(_ sender: UIButton) {
        
      
        
    }
   
    
    @IBAction func infoNavButtonAction(_ sender: Any) {
        getLatestOrderDetails()
    }
    @IBAction func cartButtonAction(_ sender: Any) {
         segueCallToToProductCheckoutFromHome()
    }
    
    @IBAction func slideButton_Clicked(_ sender: UIButton) {
        orderStatusAnimation(orderStatus: "", sender)
    }
    
    func orderStatusAnimation(orderStatus: String, _ sender: UIButton) {
        
        
        
        
        
        if !isSlideIn {
            
            isSlideIn = true
            UIView.animate(withDuration: 2.0, animations: {
                
                self.labelViewLeadingConstraint.constant = 8
                self.labelViewTrailingConstraint.constant = 8
                self.view.layoutIfNeeded()
            }, completion: { (_) in
                DispatchQueue.main.async {
                    self.slideButton.setImage(UIImage(named: "left caret"), for: .normal)
                }
            })
 //
        } else {
            isSlideIn = false
            var frame = labelView.frame
            frame.origin.x = -(labelView.frame.width - slideButton.frame.width)
            
            UIView.animate(withDuration: 2.0, animations: {
                self.labelViewLeadingConstraint.constant = -(self.view.frame.width - self.slideButton.frame.width)
                self.labelViewTrailingConstraint.constant = self.view.frame.width - self.slideButton.frame.width
                self.slideButton.imageView?.image = UIImage(named: "left caret")
                
                self.view.layoutIfNeeded()
                
            }, completion: { (_) in
                DispatchQueue.main.async {
                    self.slideButton.setImage(UIImage(named: "right caret"), for: .normal)
                     self.popTip.removeFromSuperview()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        if let orderId = UserDefaults.standard.string(forKey: "OpenOrderId") {
                            self.updateOrderStatus(orderId: "\(orderId)", orderStatus: "\(UserDefaults.standard.string(forKey: "OpenOrderStatus")!)")
                        }
                    }
                    
                }
            })
            
        }
    }
    
    func getLatestOrderDetails()
    {
         // let todosEndpoint: String = /*Configuration.API.URLString*/ "" + "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        let todosEndpoint: String = "http://alexa-cafe.cloudhub.io/alexa/" + /*"order/cc8deee2da54d5e6"*/  "order/\(UserDefaults.standard.string(forKey: "uuidString")!)"
        //let url = todosEndpoint.data(using: String.Encoding.utf8)
        
        loadingView.isHidden = false
        
        OrderListRequest(url: todosEndpoint, methodType: .get, encoding: JSONEncoding.default).getOrderList({ (orderDict) in
            
            self.loadingView.isHidden = true
            
            if orderDict.count > 0 {
                
                let orderId = orderDict["orderId"] as! Int
                let orderStatus = orderDict["status"] as! String
                
                self.showAlert(title: "", message: orderStatus ,orderId:"\(orderId)",orderStatus:"\(orderStatus)")
            } else {
                self.showAlert(title: "", message: "No active order found.",orderId:"",orderStatus:"")
            }
            
        }) { (error) in
            self.loadingView.isHidden = true
        }
       
    }
    
    
    func showAlert(title:String, message:String, orderId:String, orderStatus:String) {
        if(orderId == "") {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
           
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
             
            alert.dismiss(animated: false, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
           
        } else {
            //first api call
            let alert = UIAlertController(title: title, message: "Order No. is " + orderId, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: (orderStatus == "complete" ? "OK" : "Done"), style: .default, handler: { action in
                
                if(orderStatus == "complete")
                {
                    alert.dismiss(animated: true, completion: {
                        
                    })
                }else{
                    
                    let urlString: String = Constants.API.placeOrderUrl
                    self.loadingView.isHidden = false
                    OrderListRequest(url: urlString, methodType: .put, encoding: JSONEncoding.default, parameters: ["orderId": orderId,"status":orderStatus], headers: [:]).postOrderList({ (orderDict) in
                        
                        self.loadingView.isHidden = true
                        
                        _ = orderDict["orderId"] as! Int
                        let orderStatus = orderDict["status"] as! String
                        
                        //self.showAlert(title: "", message: orderStatus ,orderId:"",orderStatus:"")
                        self.bannerView = Banner(title: nil, subtitle: orderStatus, image: nil, backgroundColor: UIColor.gray)
                        self.bannerView?.dismissesOnTap = true
                        self.bannerView?.position = .bottom
                        self.bannerView?.minimumHeight = 60
                        self.bannerView?.isOpaque = true
                        self.bannerView?.show(duration: 3.0)
                        //self.orderStatusAnimation(orderStatus: orderStatus)
                        
                    }, failure: { (error) in
                        print(error!)
                        
                        self.loadingView.isHidden = true
                    })
                    
                }
                
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
                //cancel
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func updateOrderStatus(orderId:String,orderStatus:String)
    {
        
        let urlString: String = Constants.API.placeOrderUrl
       // self.loadingView.isHidden = false
        OrderListRequest(url: urlString, methodType: .put, encoding: JSONEncoding.default, parameters: ["orderId": orderId,"status":orderStatus], headers: [:]).postOrderList({ (orderDict) in
            
           // self.loadingView.isHidden = true
            
            _ = orderDict["orderId"] as! Int
            let orderStatus = orderDict["status"] as! String
            
            //self.showAlert(title: "", message: orderStatus ,orderId:"",orderStatus:"")
            self.bannerView = Banner(title: nil, subtitle: orderStatus, image: nil, backgroundColor: UIColor.gray)
            self.bannerView?.dismissesOnTap = true
            self.bannerView?.position = .bottom
            self.bannerView?.minimumHeight = 60
            self.bannerView?.isOpaque = true
            self.bannerView?.show(duration: 3.0)
            //self.orderStatusAnimation(orderStatus: orderStatus)
            self.orderStatusLabel.text = "No active order found."
            
        }, failure: { (error) in
            print(error!)
            
            //self.loadingView.isHidden = true
        })
        
    }
    
    
    @IBAction func favouriteButton_Clicked(_ sender: UIButton) {
        self.performSegue(withIdentifier: "favouriteProductSegue", sender: self)
    }
    
    
    @IBAction func promotionButton_Clicked(_ sender: UIButton) {
        self.performSegue(withIdentifier: "promotionProductSegue", sender: self)
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "favouriteProductSegue" {
            let productListVC = segue.destination as! ProductListViewController
            productListVC.isFavouriteProductList = true
        } else if segue.identifier == "promotionProductSegue" {
            let productListVC = segue.destination as! ProductListViewController
            productListVC.isFavouriteProductList = false
        }
    }

    
}
