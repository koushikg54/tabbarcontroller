//
//  CartItemManager.swift
//  KrystaCafe
//
//  Created by koushik ghosh on 24/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Foundation

class CartItemManager: NSObject {
    
    
    public static var cartItemsDict:[CartItem1:CartItemData] = [:]
    
    
    public static func updateCart(cartItem:CartItem1 ,count:Int,isAdd:Bool ) {
        
        if (count > 0) {
            
            var cartItemKey:CartItem1 = CartItem1()
            var isFound:Bool = false
            if(cartItemsDict.count > 0)
            {
                for item in cartItemsDict
                {
                    if (item.key.productID == cartItem.productID)
                    {
                        cartItemKey = item.key
                        isFound = true
                        break;
                    }
                }
                if(isFound == false)
                {
                    let cartItemObj1:CartItemData = CartItemData(count: count, price: cartItem.price)
                    
                    cartItemsDict.updateValue(cartItemObj1, forKey: cartItem)
                }else{
                    let cartItemObj:CartItemData = cartItemsDict[cartItemKey]!
                    cartItemKey.cartQuantityNo = count
                    cartItemObj.count = count
                    cartItemObj.price =  convertToTotalPriceWithDollor(price: cartItemsDict[cartItemKey]!.price, count: count)//cartItemsDict[cartItemKey]!.price//cartItem.price
                    cartItemsDict.updateValue(cartItemObj, forKey: cartItemKey)
                }
            }else{
                let cartItemObj:CartItemData = CartItemData(count: 1, price: cartItem.price)
                cartItemsDict.updateValue(cartItemObj, forKey: cartItem)
            }
        } else {
            // cartItemsDict.removeValue(forKey: cartItem)
            
            for item in cartItemsDict
            {
                if (item.key.productID == cartItem.productID)
                {
                    cartItemsDict.removeValue(forKey: item.key)
                    
                }
            }
            
        }
    }
    
    
    public static func getCartItemsAsList() -> [CartItem1] {
        var cartItemList:[CartItem1] = []
        
        for item in cartItemsDict
        {
            cartItemList.append(item.key)
            
        }
        
        return cartItemList;
    }
    public static func getTotalCartItemsPrice() -> String {
        
        var cartItemList:[CartItem1] = []
        var sumPrice:Double = 0
        for item in cartItemsDict
        {
            cartItemList.append(item.key)
            
        }
        for item in cartItemList
        {
            sumPrice = sumPrice + Double( convertToTotalPriceWithOutDollor(price: item.productPrice, count: item.cartQuantityNo))!
        }
        
        
        return "$ " + "\(sumPrice)"
    }
    public static func getTotalCartItemsPriceWithoutDollor() -> String {
        
        var cartItemList:[CartItem1] = []
        var sumPrice:Double = 0
        for item in cartItemsDict
        {
            cartItemList.append(item.key)
            
        }
        for item in cartItemList
        {
            sumPrice = sumPrice + Double( convertToTotalPriceWithOutDollor(price: item.productPrice, count: item.cartQuantityNo))!
        }
        
        
        return "\(sumPrice)"
    }
    public static func getCartItems() -> [CartItem1:CartItemData] {
        return cartItemsDict;
    }
    public static func getCartItemsCount() -> Int {
        return cartItemsDict.count
        
    }
    public static func convertToTotalPriceWithDollor(price:String,count:Int) -> String {
    
        var unitPrice:String!
        unitPrice = price.replacingOccurrences(of: "$", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
        let totalPrice = "$ " +  "\(((Double(unitPrice))! * Double(count)))"
        //let totalPrice = "$ " +  "\((34 * Double(count)))"
        return  totalPrice
    }
    public static func convertToTotalPriceWithOutDollor(price:String,count:Int) -> String {
        
        var unitPrice:String!
        unitPrice = price.replacingOccurrences(of: "$", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
        let totalPrice = "\(((Double(unitPrice))! * Double(count)))"
        //let totalPrice = "$ " +  "\((34 * Double(count)))"
        return  totalPrice
    }
}
