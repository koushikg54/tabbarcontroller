//
//  GetProductImageRequest.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import UIKit
import Alamofire

class GetImageRequest
{
    var request: DataRequest
    
    init(url: String)
    {
        request = SessionManager.sharedInstance.request(url, method: .get, parameters: nil, headers: nil) //SessionManager.sharedInstance.apiURLString + "/getImage?url=" + url) for HTTPS, i.e. no ATS exception needed
    }
    
    func getImage(_ success: @escaping (UIImage) -> Void, failure: @escaping (Error?) -> Void)
    {
        print("GetImageRequest: \(request.request!.url!.absoluteString)")
        request.response
            {
                response in
                
                if (response.data?.count)! != 0 {
                    if response.response != nil {
                        if response.response?.statusCode == 200 {
                            success(UIImage(data: response.data!)!)
                        }
                    }
                } else {
                    print(response.error!)
                    failure(response.error!)
                }
        }
        request.resume()
    }
}
