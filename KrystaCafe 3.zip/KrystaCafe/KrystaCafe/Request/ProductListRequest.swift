//
//  ProductListRequest.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 22/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Alamofire

class ProductListRequest {
    
    var request: DataRequest
    
    init() {
        request = SessionManager.sharedInstance.request( Constants.API.baseUrl + "product", method: .get, parameters: nil, headers: nil)
    }
    
    func getFavouritesProductList(_ success: @escaping ([Product]) -> Void, failure: @escaping (Error?) -> Void) {
        let productDict = [["productName": "Product name1", "productDesc": "Product description", "listPrice": "34$", "quantityNo": 0, "productID": "1"], ["productName": "Product name2", "productDesc": "Product description", "listPrice": "12$", "quantityNo": 0, "productID": "2"]]
        var products = [Product]()
        
        print("GetAppsRequest: \(request.request!.url!.absoluteString)")
        request.response
            {
                response in
                
                if response.response != nil {
                    let responseString = String(data: response.data!, encoding: String.Encoding.utf8)
                    print("GetAppsResponse: \(responseString!)")
                    let JSON = try? JSONSerialization.jsonObject(with: response.data!, options: JSONSerialization.ReadingOptions.allowFragments)
                    if JSON != nil {
                        let root = JSON as! [String : AnyObject]
                        let productArray = root["apps"] as! [[String : AnyObject]]
                        
                        for item in productArray {
                            
                            products.append(Product(productDict: item))
                        }
                        success(products)
                    } else {
                        for item in productDict {
                            products.append(Product(productDict: item))
                        }
                        success(products)
                    }
                }
                else {
                    for item in productDict {
                        products.append(Product(productDict: item))
                    }
                    success(products)
                }
        }
        request.resume()
    }
}
