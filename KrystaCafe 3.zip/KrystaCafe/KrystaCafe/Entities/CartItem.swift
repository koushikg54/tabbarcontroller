//
//  CartItem.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 24/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

class CartItem {
    var quantityNo: Int = 0
    var productType: String = ""
    var productID: Int = 0
    var productDesc: String = ""
    var productPrice: String = ""
    var productName: String = ""
    var imageUrl: String = ""
    var products = [Product]()
    var promotion = [Promotions]()
    
    init() {
        
    }
    
    init(quantityNo: Int, productID: Int, productDesc: String, productName: String,  productPrice: String, imageUrl: String) {
        self.quantityNo = quantityNo
        self.productID = productID
        self.productDesc = productDesc
        self.productName = productName
        self.productPrice = productPrice
        self.imageUrl = imageUrl
    }
}
