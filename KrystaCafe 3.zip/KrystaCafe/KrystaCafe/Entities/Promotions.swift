//
//  Promotions.swift
//  KrystaCafe
//
//  Created by Tushar Shende on 23/05/18.
//  Copyright © 2018 McDonald's. All rights reserved.
//

import Foundation

class Promotions {
    
    /*"promoID": "42",
     "promoName": "There's A Big Mac For That",
     "promoType": "Item",
     "promoDescr": "We now have three big mac sizes, the Big Mac, Grand Mac, or Mac Jr.",
     "promoCode": "MAC4THAT",
     "promoValue": "Item",
     "promoStartDate": "1/1/2017",
     "promoEndDate": null,
     "tenantID": "17",
     "promoCategory": "Marketing",
     "promoCost": null,
     "PromoQty": null*/
    
    var promoID : String = ""
    var promoName: String = ""
    var promoType: String = ""
    var promoDescr: String = ""
    var promoCode: String = ""
    var promoValue: String = ""
    var promoStartDate: String = ""
    var promoEndDate: String = ""
    var tenantID: String = ""
    var promoCategory: String = ""
    var promoCost: String = ""
    var promoQty: Int = 0
    var productIsAdded: Bool = false
    
    init( dict: [String : Any]) {
        self.promoID = dict["promoID"] as? String ?? ""
        self.promoName = dict["promoName"] as? String ?? ""
        self.promoType = dict["promoType"] as? String ?? ""
        self.promoDescr = dict["promoDescr"] as? String ?? ""
        self.promoCode = dict["promoCode"] as? String ?? ""
        self.promoValue = dict["promoValue"] as? String ?? ""
        self.promoStartDate = dict["promoStartDate"] as? String ?? ""
        self.promoEndDate = dict["promoEndDate"] as? String ?? ""
        self.tenantID = dict["tenantID"] as? String ?? ""
        self.promoCategory = dict["promoCategory"] as? String ?? ""
        self.promoCost = dict["promoCost"] as? String ?? ""
        self.promoQty = dict["promoQty"] as? Int ?? 0
    }
}
